import { onCall } from 'firebase-functions/v2/https';
import { onSchedule } from 'firebase-functions/v2/scheduler';
import { HttpsError } from 'firebase-functions/v2/https';
import * as admin from 'firebase-admin';
import { runMagiconCrawler } from './magiconCrawler';

admin.initializeApp();

// 📍 Manuell trigger fra nettside (via httpsCallable)
export const runCrawlers = onCall(async (request) => {
  try {
    const result = await runMagiconCrawler();
    return { message: 'Kjørte crawler', result };
  } catch (err: any) {
    console.error('Feil i runCrawlers:', err);
    throw new HttpsError('internal', 'Crawler feilet', err.message);
  }
});

// ⏰ Automatisk cronjob (hver 12. time)
export const scheduledCrawler = onSchedule(
  { schedule: 'every 12 hours', timeZone: 'Europe/Oslo' },
  async () => {
    try {
      const result = await runMagiconCrawler();
      console.log('Cronjob resultat:', result);
    } catch (err) {
      console.error('Cronjob feilet:', err);
    }
  }
);
