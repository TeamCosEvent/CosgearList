import { useEffect, useState, useRef } from "react";
import {
  onSnapshot,
  collection,
  query,
  orderBy,
  DocumentData,
  Timestamp,
} from "firebase/firestore";
import { db } from "@/firebase/firebaseConfig";

type NotificationItem = {
  id: string;
  type: "event";
  title?: string;
  location?: string;
  timestamp?: Timestamp;
  message: string;
};

export const useRealtimeNotifications = () => {
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const previousStates = useRef<Record<string, boolean>>({});
  const knownDocs = useRef<Set<string>>(new Set());

  useEffect(() => {
    const q = query(collection(db, "conventions"), orderBy("createdAt", "desc"));

    const unsub = onSnapshot(q, (snapshot) => {
      const newNotifications: NotificationItem[] = [];

      snapshot.docs.forEach((doc) => {
        const data = doc.data() as DocumentData;
        const id = doc.id;
        const title = data.title ?? "Uten tittel";
        const location = data.location ?? "";
        const timestamp: Timestamp =
          data.createdAt instanceof Timestamp ? data.createdAt : Timestamp.now();
        const isVisible = data.isVisible ?? true;

        const wasKnown = knownDocs.current.has(id);
        const previousVisibility = previousStates.current[id];

        // Lagre nåværende tilstand
        previousStates.current[id] = isVisible;
        knownDocs.current.add(id);

        // Ny convention
        if (!wasKnown) {
          newNotifications.push({
            id: `new-${id}`,
            type: "event",
            title,
            location,
            timestamp,
            message: `Ny convention lagt til: ${title}`,
          });
        }

        // Endring i synlighet
        if (wasKnown && previousVisibility !== isVisible) {
          newNotifications.push({
            id: `toggle-${id}-${Date.now()}`,
            type: "event",
            title,
            location,
            timestamp,
            message: isVisible
              ? `Convention gjort synlig: ${title}`
              : `Convention skjult: ${title}`,
          });
        }
      });

      if (newNotifications.length > 0) {
        console.log("🔔 Nye notifikasjoner:", newNotifications);
      }

      setNotifications((prev) =>
        [...newNotifications, ...prev].sort(
          (a, b) =>
            (b.timestamp?.toMillis?.() ?? 0) - (a.timestamp?.toMillis?.() ?? 0)
        )
      );
    });

    return () => unsub();
  }, []);

  return notifications;
};
