'use client';

import { useEffect, useState } from 'react';
import {
  collection,
  doc,
  onSnapshot,
  updateDoc,
  deleteDoc,
  Timestamp,
} from 'firebase/firestore';
import { db } from '@/firebase/firebaseConfig';
import AdminNavbar from '@/components/AdminNavbar';

type ConventionEvent = {
  id: string;
  title: string;
  date: string;
  location: string;
  link?: string;
  source?: string;
  isVisible?: boolean;
  isNew?: boolean;
  createdAt?: Timestamp;
};

export default function ConventionListPage() {
  const [events, setEvents] = useState<ConventionEvent[]>([]);
  const [search, setSearch] = useState('');
  const [crawlerStatus, setCrawlerStatus] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const q = collection(db, 'conventions');
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as ConventionEvent[];
      setEvents(data);
    });
    return () => unsubscribe();
  }, []);

  const toggleVisibility = async (id: string, current: boolean | undefined) => {
    await updateDoc(doc(db, 'conventions', id), {
      isVisible: !current,
      isNew: false,
    });
  };

  const deleteEvent = async (id: string) => {
    const confirm = window.confirm('Er du sikker på at du vil slette dette eventet?');
    if (!confirm) return;
    await deleteDoc(doc(db, 'conventions', id));
  };

  const triggerCrawler = async () => {
    setLoading(true);
    setCrawlerStatus('Kjører crawler...');
    try {
      const res = await fetch('/api/crawlMagicon');
      const json = await res.json();
      setCrawlerStatus(json.message || 'Crawler ferdig!');
    } catch {
      setCrawlerStatus('Feil ved kjøring av crawler.');
    } finally {
      setLoading(false);
      setTimeout(() => setCrawlerStatus(''), 5000);
    }
  };

 const filtered = events.filter((event) => {
  const term = search.toLowerCase();
  return (
    event.title?.toLowerCase().includes(term) ||
    event.location?.toLowerCase().includes(term)
  );
});


  return (
    <>
      <AdminNavbar />
      <main className="max-w-6xl px-6 pb-12 mx-auto pt-28">
        <h1 className="text-2xl font-bold mb-4 text-[var(--cosevent-yellow)]">
          Alle lagrede events
        </h1>

        <button
          onClick={triggerCrawler}
          className="mb-4 btn-primary disabled:opacity-50"
          disabled={loading}
        >
          {loading ? 'Kjører crawler...' : 'Kjør crawler manuelt'}
        </button>

        {crawlerStatus && (
          <p className="mb-6 text-white bg-black/30 p-2 rounded">{crawlerStatus}</p>
        )}

        <input
          type="text"
          placeholder="Søk etter tittel, sted eller kilde..."
          className="w-full px-4 py-2 mb-6 text-white border border-gray-300 rounded"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />

        <div className="overflow-x-auto">
          <table className="min-w-[1000px] w-full text-sm border rounded">
            <thead>
              <tr className="text-left" style={{ backgroundColor: 'var(--cosevent-yellow)' }}>
                <th className="p-2">Tittel</th>
                <th className="p-2">Dato</th>
                <th className="p-2">Sted</th>
                <th className="p-2">Kilde</th>
                <th className="p-2">Synlig</th>
                <th className="p-2">Handlinger</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((event) => (
                <tr key={event.id} className="border-t">
                  <td className="p-2">{event.title}</td>
                  <td className="p-2">{event.date}</td>
                  <td className="p-2">{event.location}</td>
                  <td className="p-2">{event.source}</td>
                  <td className="p-2">{event.isVisible ? '✅' : '❌'}</td>
                  <td className="flex gap-2 p-2">
                    <button
                      className="text-blue-600 underline"
                      onClick={() => toggleVisibility(event.id, event.isVisible)}
                    >
                      {event.isVisible ? 'Skjul' : 'Vis'}
                    </button>
                    <button
                      className="text-red-600 underline"
                      onClick={() => deleteEvent(event.id)}
                    >
                      Slett
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>
    </>
  );
}
